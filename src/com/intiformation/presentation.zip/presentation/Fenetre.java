package com.intiformation.presentation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.intiformation.tpcomptes.modele.Client;
import com.intiformation.tpcomptes.modele.Compte;
import com.intiformation.tpcomptes.service.ClientService;
import com.intiformation.tpcomptes.service.CompteService;

public class Fenetre extends JFrame {

	private JPanel container = new JPanel();
	private JComboBox<String> combo = new JComboBox<>();
	private JLabel clientLabel = new JLabel("Vous �tes : ");
	private ClientService clientServ = new ClientService();
	private CompteService compteServ = new CompteService();
	private JButton ajoutClient = new JButton("Nouveau client");
	private PartieCentrale centre = new PartieCentrale();
	private List<Client> listeClients;

	public Fenetre(){
		this.setTitle("Gestion Comptes");
		this.setSize(300, 300);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
		this.setVisible(true);

		BorderLayout bl = new BorderLayout();
		//bl.setVgap(10);
		//bl.setHgap(10);
		container.setLayout(bl);
		container.add(combo);

		JPanel top = new JPanel();
		top.add(clientLabel);
		top.add(combo);
		JPanel ctr2 = new JPanel();
		ctr2.setLayout(new FlowLayout());
		ctr2.add(ajoutClient);
		container.add(top, BorderLayout.NORTH);
		container.add(ctr2, BorderLayout.SOUTH);
		container.add(centre, BorderLayout.CENTER);
		combo.addActionListener(new ComboListener());
		//combo.addItem("");

		ajoutClient.addActionListener(new AddClientListener());

		this.setContentPane(container);   

		listeClients = clientServ.findAll();

		for (Client client : listeClients) {
			combo.addItem(client.getPrenom() + " " + client.getNom());
		}


	}


	class ComboListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			centre.setClient(listeClients.get(combo.getSelectedIndex()));
			centre.setCompte(compteServ.findByClientId(listeClients.get(combo.getSelectedIndex()).getId_Client()));
		}  
	}    

	class AddClientListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {

			FenetreCreationClient fcc = new FenetreCreationClient();
			if (fcc.ajouterClient())
			{
				Client newClient = clientServ.findAll().get(clientServ.findAll().size()-1);
				combo.addItem(newClient.getPrenom() + " " + newClient.getNom());
			}

		}  
	}    

}
