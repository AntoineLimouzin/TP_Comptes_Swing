package com.intiformation.presentation;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JOptionPane;

import com.intiformation.tpcomptes.modele.Client;
import com.intiformation.tpcomptes.modele.Compte;
import com.intiformation.tpcomptes.modele.Compte_Courant;
import com.intiformation.tpcomptes.modele.Compte_Epargne;
import com.intiformation.tpcomptes.service.ClientService;
import com.intiformation.tpcomptes.service.CompteService;



public class FenetreCreationClient {

	private CompteService compteServ = new CompteService();
	private ClientService clientServ = new ClientService();

	public FenetreCreationClient() {
		
	}

	public boolean ajouterClient()
	{
		String prenom = JOptionPane.showInputDialog(null, "Pr�nom ?", "Infos", JOptionPane.QUESTION_MESSAGE);
		String nom = JOptionPane.showInputDialog(null, "Nom ?", "Infos", JOptionPane.QUESTION_MESSAGE);
		String adresse = JOptionPane.showInputDialog(null, "Adresse ?", "Infos", JOptionPane.QUESTION_MESSAGE);
		String ville = JOptionPane.showInputDialog(null, "Ville ?", "Infos", JOptionPane.QUESTION_MESSAGE);
		Integer codePostal;

		String postalCodeStr = JOptionPane.showInputDialog(null, "Code postal ?", "Infos", JOptionPane.QUESTION_MESSAGE);
		try {
			codePostal = Integer.parseInt(postalCodeStr);
		} catch (NumberFormatException e) {
			codePostal = null;
		}

		String telephone = JOptionPane.showInputDialog(null, "Num�ro de t�l�phone ?", "Infos", JOptionPane.QUESTION_MESSAGE);

		String types[] = {"Compte normal", "Compte courant", "Compte epargne"};

		String type = (String) JOptionPane.showInputDialog(null, 
				"Quel type de compte ?",
				"Infos",
				JOptionPane.QUESTION_MESSAGE,
				null,
				types, types[0]);
		Compte nouveauCompte = null;

		String propsStrArr[] = {prenom, nom, adresse, ville, telephone, type};
		
		ArrayList<String> propsStr = new ArrayList<>(Arrays.asList(propsStrArr));



		if (codePostal != null && !propsStr.contains(null))
		{
			switch (type) {
			case "Compte normal":
				nouveauCompte = new Compte();
				break;
			case "Compte courant":
				nouveauCompte = new Compte_Courant();
				break;
			case "Compte epargne":
				nouveauCompte = new Compte_Epargne();
				break;
			default:
				break;
			}

			compteServ.ajouter(nouveauCompte);

			int compte_id = compteServ.findAll().get(compteServ.findAll().size()-1).getId_Compte();

			clientServ.ajouter(new Client(nom, prenom, adresse, codePostal, ville, telephone, compte_id));
			
			JOptionPane.showMessageDialog(null, "Ajout effectu� avec succ�s", "Infos du compte", JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Ajout impossible", "Info", JOptionPane.WARNING_MESSAGE);
			return false;
		}
	}

}
